package thearknoah05.missy.client.models.consoles;

import net.minecraft.tileentity.TileEntity;
import net.tardis.mod.entity.ControlEntity;
import net.tardis.mod.tileentities.ConsoleTile;

public class ConsoleControlTransform {

    public static void moveControlPositions(TileEntity tile)
    {
    }

    public static void updateControlSize(TileEntity tile)
    {

    }


}
