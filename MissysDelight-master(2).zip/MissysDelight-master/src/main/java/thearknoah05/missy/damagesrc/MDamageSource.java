package thearknoah05.missy.damagesrc;

import thearknoah05.missy.Missy;
import net.minecraft.util.DamageSource;

public class MDamageSource {

    public static final DamageSource ELECTRICITY = new DamageSource(Missy.MODID + ":electricity").setDamageIsAbsolute();

}
