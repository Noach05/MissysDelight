package thearknoah05.missy.events;

import thearknoah05.missy.Missy;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Missy.MODID)
public class RenderEvents {



}
