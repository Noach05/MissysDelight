package thearknoah05.missy.items;

import net.minecraft.item.Item;

public class MItemProperties {

    public static Item.Properties BLOCK = new Item.Properties();

}
