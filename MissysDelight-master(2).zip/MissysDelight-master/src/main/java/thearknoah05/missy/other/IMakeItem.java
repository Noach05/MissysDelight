package thearknoah05.missy.other;

import net.minecraft.item.Item;

public interface IMakeItem {

    Item getItem();

}
