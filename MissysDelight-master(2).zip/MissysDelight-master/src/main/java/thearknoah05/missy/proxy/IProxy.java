package thearknoah05.missy.proxy;

public interface IProxy {

    default void init() {}

}
