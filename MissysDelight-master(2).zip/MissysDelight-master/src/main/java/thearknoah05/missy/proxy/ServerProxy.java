package thearknoah05.missy.proxy;

public class ServerProxy implements IProxy {
}
