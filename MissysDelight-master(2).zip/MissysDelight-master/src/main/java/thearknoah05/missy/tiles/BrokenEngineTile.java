package thearknoah05.missy.tiles;

import net.minecraft.tileentity.TileEntity;


public class BrokenEngineTile extends TileEntity {


    public BrokenEngineTile() {
        super(MTiles.BROKEN_ENGINE);
    }




}
